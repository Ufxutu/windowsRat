import autopy


def send_key_press(key):
    autopy.key.type_string(key)
