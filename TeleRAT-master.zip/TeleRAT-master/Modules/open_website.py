import webbrowser


def open_website(website):
    webbrowser.open(f"{website}")
